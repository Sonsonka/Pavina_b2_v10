package com.example.pavinasv_02_10

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class CalcCostApart : AppCompatActivity() {
    lateinit var btnBack: Button
    lateinit var calcBtn: Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_calc_cost_apart)
        btnBack = findViewById(R.id.backBtn)
        calcBtn = findViewById(R.id.calcbtn)

        btnBack.setOnClickListener{
            val intent = Intent(this@CalcCostApart, MainActivity::class.java)
            startActivity(intent)}
        calcBtn.setOnClickListener{
            val intent = Intent(this@CalcCostApart, ResultCalculate::class.java)
            startActivity(intent)}
        }

    }
}