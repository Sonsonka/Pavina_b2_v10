package com.example.pavinasv_02_10

import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ShareActionProvider

class MainActivity : AppCompatActivity() {
    lateinit var login: EditText
    lateinit var password: EditText
    lateinit var nextbtn: Button
    lateinit var settings: SharedPreferences
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        login = findViewById(R.id.login)
        password = findViewById(R.id.password)
        nextbtn = findViewById(R.id.btnnext)

        settings = getSharedPreferences("PREF", MODE_PRIVATE)
        if(settings.contains(login.text.toString()) && settings.contains(password.text.toString())){

        }

        nextbtn.setOnClickListener{
            if(login.text.isNullOrEmpty() && password.text.isNullOrEmpty()){
                var edit = settings.edit()
                edit.putString(login.text.toString(), "login")
                edit.putString(password.text.toString(), "password")
                edit.apply()
                val intent = Intent(this@MainActivity, CalcCostApart::class.java)
                startActivity(intent)
            }
        }
    }
}